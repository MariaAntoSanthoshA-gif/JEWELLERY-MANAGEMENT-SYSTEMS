package com.jewellery.service;

import com.jewellery.model.Jewellery;
import com.jewellery.repository.JewelleryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RecommendationService {

    private final JewelleryRepository jewelleryRepository;

    public List<Jewellery> recommend(String occasion, String budget, String gender) {
        List<Jewellery> all = jewelleryRepository.findByAvailableTrue();
        List<Jewellery> results = new ArrayList<>(all);

        // Filter by gender/category
        if (gender != null && !gender.isBlank()) {
            Jewellery.Category cat = parseCategory(gender);
            if (cat != null) {
                results = results.stream()
                        .filter(j -> j.getCategory() == cat)
                        .collect(Collectors.toList());
            }
        }

        // Filter by occasion
        if (occasion != null) {
            results = switch (occasion.toLowerCase()) {
                case "wedding" -> results.stream()
                        .filter(j -> j.getType() == Jewellery.JewelleryType.NECKLACE
                                || j.getType() == Jewellery.JewelleryType.MANGALSUTRA
                                || j.getType() == Jewellery.JewelleryType.BANGLES
                                || j.getMaterial() == Jewellery.Material.GOLD
                                || j.getMaterial() == Jewellery.Material.DIAMOND)
                        .collect(Collectors.toList());
                case "valentine" -> results.stream()
                        .filter(j -> j.getType() == Jewellery.JewelleryType.RING
                                || j.getType() == Jewellery.JewelleryType.PENDANT)
                        .collect(Collectors.toList());
                case "festival" -> results.stream()
                        .filter(j -> j.getMaterial() == Jewellery.Material.GOLD
                                || j.getMaterial() == Jewellery.Material.SILVER)
                        .collect(Collectors.toList());
                case "casual" -> results.stream()
                        .filter(j -> j.getMaterial() == Jewellery.Material.SILVER)
                        .collect(Collectors.toList());
                default -> results;
            };
        }

        // Filter by budget
        if (budget != null) {
            results = switch (budget.toLowerCase()) {
                case "low" -> results.stream()
                        .filter(j -> j.getMaterial() == Jewellery.Material.SILVER)
                        .collect(Collectors.toList());
                case "medium" -> results.stream()
                        .filter(j -> j.getMaterial() == Jewellery.Material.GOLD
                                || j.getMaterial() == Jewellery.Material.SILVER)
                        .collect(Collectors.toList());
                case "high" -> results.stream()
                        .filter(j -> j.getMaterial() == Jewellery.Material.GOLD
                                || j.getMaterial() == Jewellery.Material.DIAMOND
                                || j.getMaterial() == Jewellery.Material.PLATINUM)
                        .collect(Collectors.toList());
                default -> results;
            };
        }

        return results.stream().limit(12).collect(Collectors.toList());
    }

    private Jewellery.Category parseCategory(String gender) {
        return switch (gender.toUpperCase()) {
            case "WOMEN" -> Jewellery.Category.WOMEN;
            case "MEN" -> Jewellery.Category.MEN;
            case "GIRLS" -> Jewellery.Category.GIRLS;
            case "BOYS" -> Jewellery.Category.BOYS;
            case "KIDS" -> Jewellery.Category.KIDS;
            default -> null;
        };
    }
}
