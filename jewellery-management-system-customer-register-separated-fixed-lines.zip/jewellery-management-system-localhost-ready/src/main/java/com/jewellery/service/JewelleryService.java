package com.jewellery.service;

import com.jewellery.dto.JewelleryRequest;
import com.jewellery.dto.PriceResponse;
import com.jewellery.exception.InsufficientStockException;
import com.jewellery.exception.ResourceNotFoundException;
import com.jewellery.model.Jewellery;
import com.jewellery.model.ShopConfig;
import com.jewellery.repository.JewelleryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class JewelleryService {

    private final JewelleryRepository jewelleryRepository;
    private final ShopConfigService shopConfigService;

    public Jewellery addJewellery(JewelleryRequest req) {
        Jewellery j = Jewellery.builder()
                .name(req.getName())
                .description(req.getDescription())
                .category(req.getCategory())
                .type(req.getType())
                .material(req.getMaterial())
                .weightGrams(req.getWeightGrams())
                .caratWeight(req.getCaratWeight())
                .stockQuantity(req.getStockQuantity() != null ? req.getStockQuantity() : 1)
                .imageUrl(req.getImageUrl())
                .available(true)
                .build();
        return jewelleryRepository.save(j);
    }

    public Jewellery updateJewellery(Long id, JewelleryRequest req) {
        Jewellery j = getById(id);
        if (req.getName() != null) j.setName(req.getName());
        if (req.getDescription() != null) j.setDescription(req.getDescription());
        if (req.getCategory() != null) j.setCategory(req.getCategory());
        if (req.getType() != null) j.setType(req.getType());
        if (req.getMaterial() != null) j.setMaterial(req.getMaterial());
        if (req.getWeightGrams() != null) j.setWeightGrams(req.getWeightGrams());
        if (req.getCaratWeight() != null) j.setCaratWeight(req.getCaratWeight());
        if (req.getStockQuantity() != null) j.setStockQuantity(req.getStockQuantity());
        if (req.getImageUrl() != null) j.setImageUrl(req.getImageUrl());
        return jewelleryRepository.save(j);
    }

    public void deleteJewellery(Long id) {
        Jewellery j = getById(id);
        j.setAvailable(false);
        jewelleryRepository.save(j);
    }

    public Jewellery getById(Long id) {
        return jewelleryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Jewellery not found with id: " + id));
    }

    public List<Jewellery> getAll() {
        return jewelleryRepository.findByAvailableTrue();
    }

    public List<Jewellery> getByCategory(Jewellery.Category category) {
        return jewelleryRepository.findByCategory(category);
    }

    public List<Jewellery> getByMaterial(Jewellery.Material material) {
        return jewelleryRepository.findByMaterial(material);
    }

    public List<Jewellery> getLowStock() {
        return jewelleryRepository.findByStockQuantityLessThan(3);
    }

    public PriceResponse calculatePrice(Long jewelleryId, double makingChargePercent) {
        Jewellery j = getById(jewelleryId);
        ShopConfig config = shopConfigService.getConfig();
        double metalPrice = 0;
        double basePrice = 0;

        if (j.getMaterial() == Jewellery.Material.DIAMOND) {
            metalPrice = config.getDiamondPricePerCarat();
            basePrice = (j.getCaratWeight() != null ? j.getCaratWeight() : 1.0) * metalPrice;
        } else {
            metalPrice = switch (j.getMaterial()) {
                case GOLD -> config.getGoldPricePerGram();
                case SILVER -> config.getSilverPricePerGram();
                case PLATINUM -> config.getPlatinumPricePerGram();
                default -> 0;
            };
            basePrice = j.getWeightGrams() * metalPrice;
        }

        double makingCharges = basePrice * (makingChargePercent / 100.0);
        double totalPrice = basePrice + makingCharges;

        return new PriceResponse(
                j.getId(), j.getName(), j.getWeightGrams(),
                metalPrice, basePrice, makingCharges, totalPrice, j.getMaterial().name()
        );
    }

    public void reduceStock(Long id) {
        Jewellery j = getById(id);
        if (j.getStockQuantity() <= 0) {
            throw new InsufficientStockException("Item '" + j.getName() + "' is out of stock");
        }
        j.setStockQuantity(j.getStockQuantity() - 1);
        if (j.getStockQuantity() == 0) j.setAvailable(false);
        jewelleryRepository.save(j);
    }

    public void addStock(Long id, int qty) {
        Jewellery j = getById(id);
        j.setStockQuantity(j.getStockQuantity() + qty);
        j.setAvailable(true);
        jewelleryRepository.save(j);
    }
}
