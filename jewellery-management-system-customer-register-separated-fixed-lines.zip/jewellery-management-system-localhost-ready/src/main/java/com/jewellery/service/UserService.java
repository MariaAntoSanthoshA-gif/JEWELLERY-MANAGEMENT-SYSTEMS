package com.jewellery.service;

import com.jewellery.exception.ResourceNotFoundException;
import com.jewellery.model.User;
import com.jewellery.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    public Optional<User> login(String username, String password) {
        return userRepository.findByUsernameAndPassword(username, password);
    }

    public User addStaff(String username, String password, String fullName, String phone, String email) {
        if (userRepository.findByUsername(username).isPresent()) {
            throw new IllegalArgumentException("Username already exists: " + username);
        }
        User staff = User.builder()
                .username(username)
                .password(password)
                .fullName(fullName)
                .phone(phone)
                .email(email)
                .role(User.Role.STAFF)
                .active(true)
                .build();
        return userRepository.save(staff);
    }

    public boolean usernameExists(String username) {
        return userRepository.findByUsername(username).isPresent();
    }

    public User createCustomerUser(String username, String password, String fullName, String phone, String email) {
        if (userRepository.findByUsername(username).isPresent()) {
            throw new IllegalArgumentException("Username already exists: " + username);
        }
        User customer = User.builder()
                .username(username)
                .password(password)
                .fullName(fullName)
                .phone(phone)
                .email(email)
                .role(User.Role.CUSTOMER)
                .active(true)
                .build();
        return userRepository.save(customer);
    }

    public User updateStaff(Long id, String fullName, String phone, String email) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Staff not found with id: " + id));
        if (fullName != null) user.setFullName(fullName);
        if (phone != null) user.setPhone(phone);
        if (email != null) user.setEmail(email);
        return userRepository.save(user);
    }

    public void deactivateStaff(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Staff not found with id: " + id));
        user.setActive(false);
        userRepository.save(user);
    }

    public List<User> getAllStaff() {
        return userRepository.findByRole(User.Role.STAFF);
    }

    public User getById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id));
    }

    public void createAdminIfNotExists() {
        if (userRepository.findByUsername("admin").isEmpty()) {
            User admin = User.builder()
                    .username("admin")
                    .password("admin123")
                    .fullName("Administrator")
                    .role(User.Role.ADMIN)
                    .active(true)
                    .build();
            userRepository.save(admin);
        }
    }
}
