package com.jewellery.service;

import com.jewellery.exception.ResourceNotFoundException;
import com.jewellery.model.ShopConfig;
import com.jewellery.repository.ShopConfigRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ShopConfigService {

    private final ShopConfigRepository repo;

    public ShopConfig getConfig() {
        return repo.findAll().stream().findFirst().orElse(null);
    }

    public boolean isInitialized() {
        ShopConfig config = getConfig();
        return config != null && config.isInitialized();
    }

    public ShopConfig initializeShop(String shopName, String address, String phone, String email,
                                     Double gold, Double silver, Double platinum, Double diamond) {
        ShopConfig existing = getConfig();
        if (existing != null) repo.delete(existing);
        ShopConfig config = ShopConfig.builder()
                .shopName(shopName)
                .shopAddress(address)
                .shopPhone(phone)
                .shopEmail(email)
                .goldPricePerGram(gold != null ? gold : 6500.0)
                .silverPricePerGram(silver != null ? silver : 85.0)
                .platinumPricePerGram(platinum != null ? platinum : 3200.0)
                .diamondPricePerCarat(diamond != null ? diamond : 300000.0)
                .exchangeDeductionPercent(10.0)
                .initialized(true)
                .build();
        return repo.save(config);
    }

    public ShopConfig updatePrices(Double gold, Double silver, Double platinum, Double diamond) {
        ShopConfig config = getConfig();
        if (config == null) throw new ResourceNotFoundException("Shop not configured");
        if (gold != null) config.setGoldPricePerGram(gold);
        if (silver != null) config.setSilverPricePerGram(silver);
        if (platinum != null) config.setPlatinumPricePerGram(platinum);
        if (diamond != null) config.setDiamondPricePerCarat(diamond);
        return repo.save(config);
    }

    public ShopConfig updateShopDetails(String name, String address, String phone, String email) {
        ShopConfig config = getConfig();
        if (config == null) throw new ResourceNotFoundException("Shop not configured");
        if (name != null) config.setShopName(name);
        if (address != null) config.setShopAddress(address);
        if (phone != null) config.setShopPhone(phone);
        if (email != null) config.setShopEmail(email);
        return repo.save(config);
    }

    public ShopConfig updateExchangeDeduction(Double percent) {
        ShopConfig config = getConfig();
        if (config == null) throw new ResourceNotFoundException("Shop not configured");
        if (percent != null) config.setExchangeDeductionPercent(percent);
        return repo.save(config);
    }

    public double getPriceForMaterial(String material) {
        ShopConfig config = getConfig();
        if (config == null) return 0;
        return switch (material.toUpperCase()) {
            case "GOLD" -> config.getGoldPricePerGram();
            case "SILVER" -> config.getSilverPricePerGram();
            case "PLATINUM" -> config.getPlatinumPricePerGram();
            case "DIAMOND" -> config.getDiamondPricePerCarat();
            default -> 0;
        };
    }
}
