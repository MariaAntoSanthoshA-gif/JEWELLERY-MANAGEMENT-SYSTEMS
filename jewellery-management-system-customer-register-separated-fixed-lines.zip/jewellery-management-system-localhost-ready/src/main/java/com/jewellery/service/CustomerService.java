package com.jewellery.service;

import com.jewellery.exception.ResourceNotFoundException;
import com.jewellery.model.Customer;
import com.jewellery.model.User;
import com.jewellery.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CustomerService {

    private final CustomerRepository customerRepository;
    private final UserService userService;

    /**
     * Used only for backward compatibility. Staff sales no longer create customer logins.
     */
    public Customer registerCustomer(String name, String phone, String email, String address) {
        Optional<Customer> existing = customerRepository.findByPhone(phone);
        if (existing.isPresent()) return existing.get();

        String normalizedPhone = phone == null
                ? String.valueOf(System.currentTimeMillis())
                : phone.replaceAll("\\D", "");

        if (normalizedPhone.isBlank()) {
            normalizedPhone = String.valueOf(System.currentTimeMillis());
        }
        String baseUsername = "cust" + normalizedPhone.substring(Math.max(0, normalizedPhone.length() - 6));
        String username = baseUsername;
        int suffix = 1;
        while (true) {
            try {
                String password = "cust@" + normalizedPhone.substring(Math.max(0, normalizedPhone.length() - 4));
                User user = userService.createCustomerUser(username, password, name, phone, email);
                Customer c = Customer.builder()
                        .name(name)
                        .phone(phone)
                        .email(email)
                        .address(address)
                        .user(user)
                        .loginUsername(username)
                        .loginPassword(password)
                        .build();
                return customerRepository.save(c);
            } catch (IllegalArgumentException ex) {
                username = baseUsername + suffix++;
            }
        }
    }

    public Customer selfRegisterCustomer(String name, String phone, String email, String address,
                                         String username, String password) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Full name is required");
        }
        if (phone == null || phone.isBlank()) {
            throw new IllegalArgumentException("Phone number is required");
        }
        if (email == null || email.isBlank()) {
            throw new IllegalArgumentException("Email is required");
        }
        if (address == null || address.isBlank()) {
            throw new IllegalArgumentException("Address is required");
        }
        if (username == null || username.isBlank()) {
            throw new IllegalArgumentException("Username is required");
        }
        if (password == null || password.isBlank()) {
            throw new IllegalArgumentException("Password is required");
        }
        if (customerRepository.findByPhone(phone).isPresent()) {
            throw new IllegalArgumentException("Customer already exists with this phone number");
        }
        if (userService.usernameExists(username)) {
            throw new IllegalArgumentException("Username already exists: " + username);
        }

        User user = userService.createCustomerUser(username, password, name, phone, email);
        Customer customer = Customer.builder()
                .name(name)
                .phone(phone)
                .email(email)
                .address(address)
                .user(user)
                .loginUsername(username)
                .loginPassword(password)
                .build();
        return customerRepository.save(customer);
    }

    public Optional<Customer> findByPhone(String phone) {
        return customerRepository.findByPhone(phone);
    }

    public Optional<Customer> findByUser(User user) {
        return customerRepository.findByUser(user);
    }

    public Customer getById(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found: " + id));
    }

    public List<Customer> getAll() {
        return customerRepository.findAll();
    }
}
