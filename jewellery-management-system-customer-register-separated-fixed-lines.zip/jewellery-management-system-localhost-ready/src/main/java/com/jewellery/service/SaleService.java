package com.jewellery.service;

import com.jewellery.dto.PriceResponse;
import com.jewellery.dto.SaleRequest;
import com.jewellery.exception.PaymentNotCompletedException;
import com.jewellery.exception.ResourceNotFoundException;
import com.jewellery.model.*;
import com.jewellery.repository.BillRepository;
import com.jewellery.repository.EmiPlanRepository;
import com.jewellery.repository.ExchangeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class SaleService {

    private final BillRepository billRepository;
    private final EmiPlanRepository emiPlanRepository;
    private final ExchangeRepository exchangeRepository;
    private final JewelleryService jewelleryService;
    private final CustomerService customerService;
    private final UserService userService;
    private final ShopConfigService shopConfigService;

    @Transactional
    public Bill processSale(SaleRequest req) {
        Jewellery jewellery = jewelleryService.getById(req.getJewelleryId());
        User staff = req.getStaffId() != null ? userService.getById(req.getStaffId()) : null;
        ShopConfig config = shopConfigService.getConfig();

        PriceResponse pricing = jewelleryService.calculatePrice(
                req.getJewelleryId(),
                req.getMakingChargesPercent() != null ? req.getMakingChargesPercent() : 10.0
        );

        double exchangeDeduction = 0.0;
        double returnAmount = 0.0;
        Exchange exchange = null;

        if (req.isHasExchange() && req.getOldWeightGrams() != null && req.getOldWeightGrams() > 0) {
            double metalPrice = shopConfigService.getPriceForMaterial(req.getOldMaterial());
            double grossValue = req.getOldWeightGrams() * metalPrice;
            double deductPct = config.getExchangeDeductionPercent();
            double deductAmt = grossValue * (deductPct / 100.0);
            exchangeDeduction = grossValue - deductAmt;

            exchange = Exchange.builder()
                    .oldItemDescription(req.getOldItemDescription())
                    .oldMaterial(Jewellery.Material.valueOf(req.getOldMaterial().toUpperCase()))
                    .oldWeightGrams(req.getOldWeightGrams())
                    .metalPriceAtExchange(metalPrice)
                    .grossValue(grossValue)
                    .deductionPercent(deductPct)
                    .deductionAmount(deductAmt)
                    .netExchangeValue(exchangeDeduction)
                    .build();
        }

        double payableBeforeExchange = pricing.getTotalPrice();
        double totalAmount = payableBeforeExchange - exchangeDeduction;
        if (totalAmount < 0) {
            returnAmount = Math.abs(totalAmount);
            totalAmount = 0;
        }

        if (req.getPaymentType() == Bill.PaymentType.FULL_PAYMENT || req.getPaymentType() == Bill.PaymentType.EXCHANGE_PLUS_PAYMENT) {
            if (req.getAmountPaid() == null) req.setAmountPaid(totalAmount);
            if (req.getAmountPaid() < totalAmount) {
                throw new PaymentNotCompletedException(
                        "Full payment required. Amount due: ₹" + String.format("%.2f", totalAmount));
            }
        }

        if (req.getPaymentType() == Bill.PaymentType.EMI) {
            if (req.getDownPayment() == null || req.getDownPayment() <= 0) {
                throw new PaymentNotCompletedException("Down payment is required for EMI");
            }
            if (req.getCustomerId() == null && (req.getCustomerPhone() == null || req.getCustomerPhone().isBlank())) {
                throw new IllegalArgumentException("Customer registration required for EMI");
            }
        }

        Customer customer = null;
        String custName = req.getCustomerName();
        String custPhone = req.getCustomerPhone();

        if (!req.isGuestCustomer() && req.getCustomerId() != null) {
            customer = customerService.getById(req.getCustomerId());
            custName = customer.getName();
            custPhone = customer.getPhone();
        }

        double amtPaid = req.getPaymentType() == Bill.PaymentType.EMI ? req.getDownPayment() : totalAmount;

        Bill bill = Bill.builder()
                .billNumber("BILL-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase())
                .jewellery(jewellery)
                .customer(customer)
                .staff(staff)
                .customerName(custName)
                .customerPhone(custPhone)
                .jewelleryWeight(jewellery.getWeightGrams())
                .metalPriceAtSale(pricing.getMetalPricePerGram())
                .basePrice(pricing.getBasePrice())
                .makingCharges(pricing.getMakingCharges())
                .payableBeforeExchange(payableBeforeExchange)
                .exchangeDeduction(exchangeDeduction)
                .returnAmount(returnAmount)
                .totalAmount(totalAmount)
                .amountPaid(amtPaid)
                .paymentType(req.getPaymentType())
                .status(req.getPaymentType() == Bill.PaymentType.EMI ? Bill.BillStatus.PENDING_EMI : Bill.BillStatus.COMPLETED)
                .billDate(LocalDateTime.now())
                .notes(req.getNotes())
                .build();

        bill = billRepository.save(bill);

        if (exchange != null) {
            exchange.setBill(bill);
            exchangeRepository.save(exchange);
        }

        if (req.getPaymentType() == Bill.PaymentType.EMI) {
            int months = req.getEmiMonths() == null || req.getEmiMonths() <= 0 ? 6 : req.getEmiMonths();
            double remaining = totalAmount - req.getDownPayment();
            double monthlyEmi = remaining / months;

            EmiPlan emi = EmiPlan.builder()
                    .bill(bill)
                    .customer(customer)
                    .totalAmount(totalAmount)
                    .downPayment(req.getDownPayment())
                    .remainingAmount(remaining)
                    .totalMonths(months)
                    .monthlyEmi(monthlyEmi)
                    .paidMonths(0)
                    .totalPaid(req.getDownPayment())
                    .status(EmiPlan.EmiStatus.ACTIVE)
                    .nextDueDate(LocalDate.now().plusMonths(1))
                    .build();
            emiPlanRepository.save(emi);
        }

        jewelleryService.reduceStock(req.getJewelleryId());
        return bill;
    }

    @Transactional
    public Bill processCustomerOrder(Long customerId, Long jewelleryId, String paymentMethod,
                                     String transactionId, Double amountPaid) {
        Customer customer = customerService.getById(customerId);
        PriceResponse pricing = jewelleryService.calculatePrice(jewelleryId, 10.0);

        if (amountPaid == null) {
            amountPaid = pricing.getTotalPrice();
        }
        if (amountPaid < pricing.getTotalPrice()) {
            throw new PaymentNotCompletedException(
                    "Full payment required. Amount due: ₹" + String.format("%.2f", pricing.getTotalPrice()));
        }

        SaleRequest req = new SaleRequest();
        req.setJewelleryId(jewelleryId);
        req.setCustomerId(customerId);
        req.setGuestCustomer(false);
        req.setPaymentType(Bill.PaymentType.FULL_PAYMENT);
        req.setAmountPaid(amountPaid);
        req.setMakingChargesPercent(10.0);
        req.setNotes("Customer online order | Payment method: "
                + (paymentMethod == null || paymentMethod.isBlank() ? "Not specified" : paymentMethod)
                + " | Transaction ID: "
                + (transactionId == null || transactionId.isBlank() ? "Not provided" : transactionId));
        req.setCustomerName(customer.getName());
        req.setCustomerPhone(customer.getPhone());
        return processSale(req);
    }

    public EmiPlan recordEmiPayment(Long emiId) {
        EmiPlan emi = emiPlanRepository.findById(emiId)
                .orElseThrow(() -> new ResourceNotFoundException("EMI plan not found: " + emiId));

        if (emi.getStatus() == EmiPlan.EmiStatus.COMPLETED) {
            throw new IllegalArgumentException("EMI already fully paid");
        }

        emi.setPaidMonths(emi.getPaidMonths() + 1);
        emi.setTotalPaid(emi.getTotalPaid() + emi.getMonthlyEmi());
        emi.setNextDueDate(emi.getNextDueDate().plusMonths(1));

        if (emi.getPaidMonths() >= emi.getTotalMonths()) {
            emi.setStatus(EmiPlan.EmiStatus.COMPLETED);
            Bill bill = emi.getBill();
            bill.setStatus(Bill.BillStatus.COMPLETED);
            bill.setAmountPaid(emi.getTotalAmount());
            billRepository.save(bill);
        }

        return emiPlanRepository.save(emi);
    }

    public List<Bill> getAllBills() { return billRepository.findAll(); }

    public Bill getBillById(Long id) {
        return billRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Bill not found: " + id));
    }

    public List<Bill> getBillsByCustomer(Long customerId) {
        Customer c = customerService.getById(customerId);
        return billRepository.findByCustomer(c);
    }

    public List<EmiPlan> getActiveEmis() {
        return emiPlanRepository.findByStatus(EmiPlan.EmiStatus.ACTIVE);
    }

    public List<EmiPlan> getEmisByCustomer(Long customerId) {
        Customer c = customerService.getById(customerId);
        return emiPlanRepository.findByCustomer(c);
    }

    public Double getTotalSales() {
        Double total = billRepository.getTotalSales();
        return total != null ? total : 0.0;
    }

    public Long getTotalBillCount() {
        Long count = billRepository.getTotalBillCount();
        return count != null ? count : 0L;
    }
}
