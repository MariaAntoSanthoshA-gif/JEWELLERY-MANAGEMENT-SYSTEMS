package com.jewellery.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PriceResponse {
    private Long jewelleryId;
    private String jewelleryName;
    private Double weightGrams;
    private Double metalPricePerGram;
    private Double basePrice;
    private Double makingCharges;
    private Double totalPrice;
    private String material;
}
