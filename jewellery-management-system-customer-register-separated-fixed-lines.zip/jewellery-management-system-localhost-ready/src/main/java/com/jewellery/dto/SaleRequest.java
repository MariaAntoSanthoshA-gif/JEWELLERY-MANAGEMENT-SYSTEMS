package com.jewellery.dto;

import com.jewellery.model.Bill;
import lombok.Data;

@Data
public class SaleRequest {
    private Long jewelleryId;
    private Long staffId;

    // Customer info
    private boolean guestCustomer = true;
    private Long customerId;         // if registered
    private String customerName;     // if guest
    private String customerPhone;    // if guest

    private Bill.PaymentType paymentType;
    private Double amountPaid;

    // EMI fields
    private Double downPayment;
    private Integer emiMonths;

    // Exchange fields
    private boolean hasExchange = false;
    private String oldItemDescription;
    private String oldMaterial;
    private Double oldWeightGrams;

    private String notes;
    private Double makingChargesPercent = 10.0;
}
