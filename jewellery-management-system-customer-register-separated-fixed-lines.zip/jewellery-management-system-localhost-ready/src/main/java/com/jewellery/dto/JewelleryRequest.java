package com.jewellery.dto;

import com.jewellery.model.Jewellery;
import lombok.Data;

@Data
public class JewelleryRequest {
    private String name;
    private String description;
    private Jewellery.Category category;
    private Jewellery.JewelleryType type;
    private Jewellery.Material material;
    private Double weightGrams;
    private Double caratWeight;
    private Integer stockQuantity;
    private String imageUrl;
}
