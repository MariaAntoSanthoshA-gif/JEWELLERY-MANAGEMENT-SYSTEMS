package com.jewellery.repository;

import com.jewellery.model.EmiPlan;
import com.jewellery.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EmiPlanRepository extends JpaRepository<EmiPlan, Long> {
    List<EmiPlan> findByCustomer(Customer customer);
    List<EmiPlan> findByStatus(EmiPlan.EmiStatus status);
}
