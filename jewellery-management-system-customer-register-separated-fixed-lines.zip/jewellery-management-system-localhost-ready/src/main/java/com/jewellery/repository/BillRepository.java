package com.jewellery.repository;

import com.jewellery.model.Bill;
import com.jewellery.model.Customer;
import com.jewellery.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import java.util.Optional;

public interface BillRepository extends JpaRepository<Bill, Long> {
    Optional<Bill> findByBillNumber(String billNumber);
    List<Bill> findByCustomer(Customer customer);
    List<Bill> findByStaff(User staff);
    List<Bill> findByStatus(Bill.BillStatus status);

    @Query("SELECT SUM(b.totalAmount) FROM Bill b WHERE b.status = 'COMPLETED'")
    Double getTotalSales();

    @Query("SELECT COUNT(b) FROM Bill b WHERE b.status = 'COMPLETED'")
    Long getTotalBillCount();
}
