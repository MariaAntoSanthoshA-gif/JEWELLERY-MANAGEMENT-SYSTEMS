package com.jewellery.repository;

import com.jewellery.model.Jewellery;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface JewelleryRepository extends JpaRepository<Jewellery, Long> {
    List<Jewellery> findByCategory(Jewellery.Category category);
    List<Jewellery> findByMaterial(Jewellery.Material material);
    List<Jewellery> findByCategoryAndMaterial(Jewellery.Category category, Jewellery.Material material);
    List<Jewellery> findByCategoryAndType(Jewellery.Category category, Jewellery.JewelleryType type);
    List<Jewellery> findByAvailableTrue();
    List<Jewellery> findByStockQuantityLessThan(int quantity);
}
