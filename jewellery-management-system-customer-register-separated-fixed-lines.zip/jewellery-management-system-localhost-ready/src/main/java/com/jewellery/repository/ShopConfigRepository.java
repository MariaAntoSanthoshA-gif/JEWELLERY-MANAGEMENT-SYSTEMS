package com.jewellery.repository;

import com.jewellery.model.ShopConfig;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShopConfigRepository extends JpaRepository<ShopConfig, Long> {}
