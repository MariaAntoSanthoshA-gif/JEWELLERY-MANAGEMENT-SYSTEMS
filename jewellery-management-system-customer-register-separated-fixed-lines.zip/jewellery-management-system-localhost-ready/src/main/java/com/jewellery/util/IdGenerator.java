package com.jewellery.util;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Generates application-side Long IDs for SQLite.
 *
 * SQLite JDBC does not reliably support JDBC getGeneratedKeys() with Hibernate
 * identity inserts in this project setup. Assigning IDs before insert avoids
 * Hibernate asking the driver for generated keys.
 */
public final class IdGenerator {
    private static final AtomicLong COUNTER = new AtomicLong(System.currentTimeMillis() * 1000L);

    private IdGenerator() {
    }

    public static Long nextId() {
        return COUNTER.incrementAndGet();
    }
}
