package com.jewellery.util;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Component
public class FileStorageUtil {
    private final Path uploadDir = Paths.get("src/main/resources/static/uploads");

    public String saveImage(MultipartFile file) {
        if (file == null || file.isEmpty()) return null;
        try {
            Files.createDirectories(uploadDir);
            String original = file.getOriginalFilename() == null ? "image.jpg" : file.getOriginalFilename();
            String clean = original.replaceAll("[^a-zA-Z0-9.\\-_]", "_");
            String filename = UUID.randomUUID() + "_" + clean;
            Path target = uploadDir.resolve(filename);
            Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
            return "/uploads/" + filename;
        } catch (IOException e) {
            throw new RuntimeException("Unable to store image", e);
        }
    }
}
