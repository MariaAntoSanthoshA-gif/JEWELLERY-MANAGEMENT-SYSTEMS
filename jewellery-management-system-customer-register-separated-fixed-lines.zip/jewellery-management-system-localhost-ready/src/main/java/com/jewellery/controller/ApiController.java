package com.jewellery.controller;

import com.jewellery.dto.PriceResponse;
import com.jewellery.model.Jewellery;
import com.jewellery.service.JewelleryService;
import com.jewellery.service.ShopConfigService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class ApiController {

    private final JewelleryService jewelleryService;
    private final ShopConfigService shopConfigService;

    @GetMapping("/price/{id}")
    public ResponseEntity<PriceResponse> getPrice(
            @PathVariable Long id,
            @RequestParam(defaultValue = "10.0") double makingChargePercent) {
        return ResponseEntity.ok(jewelleryService.calculatePrice(id, makingChargePercent));
    }

    @GetMapping("/jewellery")
    public ResponseEntity<List<Jewellery>> getAll(
            @RequestParam(required=false) String category,
            @RequestParam(required=false) String material) {
        if (category != null) {
            return ResponseEntity.ok(jewelleryService.getByCategory(Jewellery.Category.valueOf(category)));
        }
        if (material != null) {
            return ResponseEntity.ok(jewelleryService.getByMaterial(Jewellery.Material.valueOf(material)));
        }
        return ResponseEntity.ok(jewelleryService.getAll());
    }

    @GetMapping("/shop/config")
    public ResponseEntity<Map<String, Object>> getShopConfig() {
        var config = shopConfigService.getConfig();
        if (config == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(Map.of(
                "shopName", config.getShopName(),
                "goldPrice", config.getGoldPricePerGram(),
                "silverPrice", config.getSilverPricePerGram(),
                "platinumPrice", config.getPlatinumPricePerGram(),
                "diamondPrice", config.getDiamondPricePerCarat()
        ));
    }
}
