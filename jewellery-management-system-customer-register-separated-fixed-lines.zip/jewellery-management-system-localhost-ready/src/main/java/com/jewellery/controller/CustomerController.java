package com.jewellery.controller;

import com.jewellery.model.Bill;
import com.jewellery.model.Customer;
import com.jewellery.model.Jewellery;
import com.jewellery.model.User;
import com.jewellery.service.CustomerService;
import com.jewellery.service.JewelleryService;
import com.jewellery.service.RecommendationService;
import com.jewellery.service.SaleService;
import com.jewellery.service.ShopConfigService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/customer")
@RequiredArgsConstructor
public class CustomerController {

    private final CustomerService customerService;
    private final SaleService saleService;
    private final JewelleryService jewelleryService;
    private final RecommendationService recommendationService;
    private final ShopConfigService shopConfigService;

    private boolean isCustomer(HttpSession session) {
        User u = (User) session.getAttribute("user");
        return u != null && u.getRole() == User.Role.CUSTOMER;
    }

    private Customer getCustomer(HttpSession session) {
        Customer customer = (Customer) session.getAttribute("customer");
        if (customer != null) return customer;
        User u = (User) session.getAttribute("user");
        if (u == null) return null;
        customer = customerService.findByUser(u).orElse(null);
        if (customer != null) session.setAttribute("customer", customer);
        return customer;
    }

    @GetMapping("/register")
    public String registerPage(Model model) {
        if (!shopConfigService.isInitialized()) return "redirect:/setup";
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        return "customer/register";
    }

    @PostMapping("/register")
    public String doRegister(@RequestParam String name,
                             @RequestParam String phone,
                             @RequestParam String email,
                             @RequestParam String address,
                             @RequestParam String username,
                             @RequestParam String password,
                             RedirectAttributes ra) {
        try {
            if (!shopConfigService.isInitialized()) return "redirect:/setup";
            customerService.selfRegisterCustomer(name, phone, email, address, username, password);
            ra.addFlashAttribute("success", "Customer account created successfully. Please login using Customer tab.");
            return "redirect:/login";
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/customer/register";
        }
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        if (!isCustomer(session)) return "redirect:/login";
        Customer customer = getCustomer(session);
        if (customer == null) return "redirect:/logout";
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        model.addAttribute("customer", customer);
        model.addAttribute("bills", saleService.getBillsByCustomer(customer.getId()));
        model.addAttribute("emis", saleService.getEmisByCustomer(customer.getId()));
        model.addAttribute("jewelleryList", jewelleryService.getAll());
        return "customer/dashboard";
    }

    @GetMapping("/products")
    public String products(HttpSession session, Model model,
                           @RequestParam(required=false) String category,
                           @RequestParam(required=false) String material) {
        if (!isCustomer(session)) return "redirect:/login";
        Customer customer = getCustomer(session);
        if (customer == null) return "redirect:/logout";
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        model.addAttribute("customer", customer);
        model.addAttribute("categories", Jewellery.Category.values());
        model.addAttribute("materials", Jewellery.Material.values());

        if (category != null && !category.isBlank()) {
            model.addAttribute("jewelleryList", jewelleryService.getByCategory(Jewellery.Category.valueOf(category)));
            model.addAttribute("selectedCategory", category);
        } else if (material != null && !material.isBlank()) {
            model.addAttribute("jewelleryList", jewelleryService.getByMaterial(Jewellery.Material.valueOf(material)));
            model.addAttribute("selectedMaterial", material);
        } else {
            model.addAttribute("jewelleryList", jewelleryService.getAll());
        }
        return "customer/products";
    }

    @GetMapping("/order/{id}")
    public String orderPage(@PathVariable Long id, HttpSession session, Model model) {
        if (!isCustomer(session)) return "redirect:/login";
        Customer customer = getCustomer(session);
        if (customer == null) return "redirect:/logout";
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        model.addAttribute("customer", customer);
        model.addAttribute("jewellery", jewelleryService.getById(id));
        model.addAttribute("pricing", jewelleryService.calculatePrice(id, 10.0));
        return "customer/order";
    }

    @PostMapping("/order")
    public String placeOrder(@RequestParam Long jewelleryId,
                             @RequestParam String paymentMethod,
                             @RequestParam(required=false) String transactionId,
                             @RequestParam Double amountPaid,
                             HttpSession session,
                             RedirectAttributes ra) {
        if (!isCustomer(session)) return "redirect:/login";
        Customer customer = getCustomer(session);
        if (customer == null) return "redirect:/logout";
        try {
            Bill bill = saleService.processCustomerOrder(customer.getId(), jewelleryId, paymentMethod, transactionId, amountPaid);
            ra.addFlashAttribute("success", "Order placed and payment recorded. Bill: " + bill.getBillNumber());
            return "redirect:/customer/dashboard";
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/customer/order/" + jewelleryId;
        }
    }

    @GetMapping("/recommend")
    public String recommend(HttpSession session, Model model,
                            @RequestParam(required = false) String occasion,
                            @RequestParam(required = false) String budget,
                            @RequestParam(required = false) String gender) {
        if (!isCustomer(session)) return "redirect:/login";
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        model.addAttribute("customer", getCustomer(session));
        if (occasion != null || budget != null || gender != null) {
            model.addAttribute("recommendations", recommendationService.recommend(occasion, budget, gender));
        }
        return "customer/recommend";
    }
}
