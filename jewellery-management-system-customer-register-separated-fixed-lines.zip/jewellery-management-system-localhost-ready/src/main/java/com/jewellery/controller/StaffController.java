package com.jewellery.controller;

import com.jewellery.dto.SaleRequest;
import com.jewellery.model.*;
import com.jewellery.service.*;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/staff")
@RequiredArgsConstructor
public class StaffController {

    private final JewelleryService jewelleryService;
    private final SaleService saleService;
    private final CustomerService customerService;
    private final ShopConfigService shopConfigService;
    private final RecommendationService recommendationService;

    private boolean isStaff(HttpSession session) {
        User u = (User) session.getAttribute("user");
        return u != null && (u.getRole() == User.Role.STAFF || u.getRole() == User.Role.ADMIN);
    }

    private User currentUser(HttpSession session) {
        return (User) session.getAttribute("user");
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        if (!isStaff(session)) return "redirect:/login";
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        model.addAttribute("jewelleryList", jewelleryService.getAll());
        model.addAttribute("activeEmis", saleService.getActiveEmis());
        return "staff/dashboard";
    }

    @GetMapping("/products")
    public String products(HttpSession session, Model model,
                           @RequestParam(required=false) String category,
                           @RequestParam(required=false) String material) {
        if (!isStaff(session)) return "redirect:/login";
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        model.addAttribute("categories", Jewellery.Category.values());
        model.addAttribute("materials", Jewellery.Material.values());

        if (category != null && !category.isBlank()) {
            model.addAttribute("jewelleryList", jewelleryService.getByCategory(Jewellery.Category.valueOf(category)));
            model.addAttribute("selectedCategory", category);
        } else if (material != null && !material.isBlank()) {
            model.addAttribute("jewelleryList", jewelleryService.getByMaterial(Jewellery.Material.valueOf(material)));
            model.addAttribute("selectedMaterial", material);
        } else {
            model.addAttribute("jewelleryList", jewelleryService.getAll());
        }
        return "staff/products";
    }

    @GetMapping("/sell/{id}")
    public String sellPage(@PathVariable Long id, HttpSession session, Model model) {
        if (!isStaff(session)) return "redirect:/login";
        Jewellery j = jewelleryService.getById(id);
        model.addAttribute("jewellery", j);
        model.addAttribute("pricing", jewelleryService.calculatePrice(id, 10.0));
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        model.addAttribute("customers", customerService.getAll());
        return "staff/sell";
    }

    @PostMapping("/sell")
    public String processSell(@RequestParam Long jewelleryId,
                              @RequestParam String paymentTypeStr,
                              @RequestParam(required=false) String customerType,
                              @RequestParam(required=false) Long customerId,
                              @RequestParam(required=false) String customerName,
                              @RequestParam(required=false) String customerPhone,
                              @RequestParam(required=false) String customerEmail,
                              @RequestParam(required=false) String customerAddress,
                              @RequestParam(required=false) Double amountPaid,
                              @RequestParam(required=false) Double downPayment,
                              @RequestParam(required=false) Integer emiMonths,
                              @RequestParam(defaultValue="false") boolean hasExchange,
                              @RequestParam(required=false) String oldItemDescription,
                              @RequestParam(required=false) String oldMaterial,
                              @RequestParam(required=false) Double oldWeightGrams,
                              @RequestParam(defaultValue="10.0") Double makingChargesPercent,
                              @RequestParam(required=false) String notes,
                              HttpSession session, RedirectAttributes ra) {
        if (!isStaff(session)) return "redirect:/login";

        try {
            User staff = currentUser(session);
            Bill.PaymentType paymentType = Bill.PaymentType.valueOf(paymentTypeStr);

            Customer selectedCustomer = null;
            if (customerId != null) {
                selectedCustomer = customerService.getById(customerId);
                customerName = selectedCustomer.getName();
                customerPhone = selectedCustomer.getPhone();
            }

            if (paymentType == Bill.PaymentType.EMI && selectedCustomer == null) {
                throw new IllegalArgumentException("Select an existing registered customer for EMI sales");
            }

            SaleRequest req = new SaleRequest();
            req.setJewelleryId(jewelleryId);
            req.setStaffId(staff.getId());
            req.setPaymentType(paymentType);
            req.setAmountPaid(amountPaid);
            req.setDownPayment(downPayment);
            req.setEmiMonths(emiMonths);
            req.setHasExchange(hasExchange);
            req.setOldItemDescription(oldItemDescription);
            req.setOldMaterial(oldMaterial);
            req.setOldWeightGrams(oldWeightGrams);
            req.setMakingChargesPercent(makingChargesPercent);
            req.setNotes(notes);
            req.setCustomerName(customerName);
            req.setCustomerPhone(customerPhone);

            if (customerId != null) {
                req.setGuestCustomer(false);
                req.setCustomerId(customerId);
            } else {
                req.setGuestCustomer(true);
            }

            Bill bill = saleService.processSale(req);
            ra.addFlashAttribute("success", "Sale completed! Bill: " + bill.getBillNumber());
            return "redirect:/staff/bill/" + bill.getId();
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/staff/sell/" + jewelleryId;
        }
    }

    @GetMapping("/bill/{id}")
    public String viewBill(@PathVariable Long id, HttpSession session, Model model) {
        if (!isStaff(session)) return "redirect:/login";
        model.addAttribute("bill", saleService.getBillById(id));
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        return "staff/bill";
    }

    @GetMapping("/emi")
    public String emiList(HttpSession session, Model model) {
        if (!isStaff(session)) return "redirect:/login";
        model.addAttribute("activeEmis", saleService.getActiveEmis());
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        return "staff/emi";
    }

    @PostMapping("/emi/pay/{id}")
    public String payEmi(@PathVariable Long id, HttpSession session, RedirectAttributes ra) {
        if (!isStaff(session)) return "redirect:/login";
        try {
            saleService.recordEmiPayment(id);
            ra.addFlashAttribute("success", "EMI installment recorded successfully");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/staff/emi";
    }

    @GetMapping("/customers")
    public String customers(HttpSession session, Model model,
                            @RequestParam(required=false) String phone) {
        if (!isStaff(session)) return "redirect:/login";
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        model.addAttribute("allCustomers", customerService.getAll());
        if (phone != null && !phone.isBlank()) {
            customerService.findByPhone(phone).ifPresent(c -> {
                model.addAttribute("customer", c);
                model.addAttribute("bills", saleService.getBillsByCustomer(c.getId()));
                model.addAttribute("emis", saleService.getEmisByCustomer(c.getId()));
            });
        }
        return "staff/customers";
    }

    @GetMapping("/recommend")
    public String recommend(HttpSession session, Model model,
                            @RequestParam(required=false) String occasion,
                            @RequestParam(required=false) String budget,
                            @RequestParam(required=false) String gender) {
        if (!isStaff(session)) return "redirect:/login";
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        if (occasion != null || budget != null || gender != null) {
            model.addAttribute("recommendations", recommendationService.recommend(occasion, budget, gender));
            model.addAttribute("occasion", occasion);
            model.addAttribute("budget", budget);
            model.addAttribute("gender", gender);
        }
        return "staff/recommend";
    }
}
