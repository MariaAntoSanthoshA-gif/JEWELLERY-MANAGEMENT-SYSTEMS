package com.jewellery.controller;

import com.jewellery.model.User;
import com.jewellery.service.ShopConfigService;
import com.jewellery.service.UserService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
@RequiredArgsConstructor
public class AuthController {

    private final UserService userService;
    private final ShopConfigService shopConfigService;

    @GetMapping("/")
    public String root(HttpSession session) {
        if (!shopConfigService.isInitialized()) return "redirect:/setup";
        if (session.getAttribute("user") != null) {
            User u = (User) session.getAttribute("user");
            return switch (u.getRole()) {
                case ADMIN -> "redirect:/admin/dashboard";
                case STAFF -> "redirect:/staff/dashboard";
                case CUSTOMER -> "redirect:/customer/dashboard";
            };
        }
        return "redirect:/login";
    }

    @GetMapping("/setup")
    public String setupPage(HttpSession session, Model model) {
        if (shopConfigService.isInitialized()) return "redirect:/login";
        return "setup";
    }

    @PostMapping("/setup")
    public String doSetup(@RequestParam String shopName,
                          @RequestParam(required = false) String address,
                          @RequestParam(required = false) String phone,
                          @RequestParam(required = false) String email,
                          @RequestParam(required = false) Double goldPricePerGram,
                          @RequestParam(required = false) Double silverPricePerGram,
                          @RequestParam(required = false) Double platinumPricePerGram,
                          @RequestParam(required = false) Double diamondPricePerCarat,
                          RedirectAttributes ra) {
        if (shopName == null || shopName.isBlank()) {
            ra.addFlashAttribute("error", "Shop name is required");
            return "redirect:/setup";
        }
        shopConfigService.initializeShop(shopName, address, phone, email,
                goldPricePerGram, silverPricePerGram, platinumPricePerGram, diamondPricePerCarat);
        userService.createAdminIfNotExists();
        ra.addFlashAttribute("success", "Shop configured! Login with admin / admin123");
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String loginPage(HttpSession session, Model model) {
        if (!shopConfigService.isInitialized()) return "redirect:/setup";
        if (session.getAttribute("user") != null) return "redirect:/";
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        return "login";
    }

    @PostMapping("/login")
    public String doLogin(@RequestParam String username,
                          @RequestParam String password,
                          @RequestParam(required = false) String role,
                          HttpSession session,
                          RedirectAttributes ra) {
        Optional<User> userOpt = userService.login(username, password);
        if (userOpt.isEmpty()) {
            ra.addFlashAttribute("error", "Invalid username or password");
            return "redirect:/login";
        }
        User user = userOpt.get();
        if (role != null && !role.isBlank() && !user.getRole().name().equalsIgnoreCase(role)) {
            ra.addFlashAttribute("error", "Please choose the correct login type for this account");
            return "redirect:/login";
        }
        if (!user.isActive()) {
            ra.addFlashAttribute("error", "Account is deactivated");
            return "redirect:/login";
        }
        session.setAttribute("user", user);
        session.setAttribute("shopConfig", shopConfigService.getConfig());
        return switch (user.getRole()) {
            case ADMIN -> "redirect:/admin/dashboard";
            case STAFF -> "redirect:/staff/dashboard";
            case CUSTOMER -> "redirect:/customer/dashboard";
        };
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}
