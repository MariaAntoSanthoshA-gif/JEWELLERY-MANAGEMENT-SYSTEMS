package com.jewellery.controller;

import com.jewellery.dto.JewelleryRequest;
import com.jewellery.model.Jewellery;
import com.jewellery.model.ShopConfig;
import com.jewellery.model.User;
import com.jewellery.service.*;
import com.jewellery.util.FileStorageUtil;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {

    private final UserService userService;
    private final JewelleryService jewelleryService;
    private final ShopConfigService shopConfigService;
    private final SaleService saleService;
    private final CustomerService customerService;
    private final FileStorageUtil fileStorageUtil;

    private boolean isAdmin(HttpSession session) {
        User u = (User) session.getAttribute("user");
        return u != null && u.getRole() == User.Role.ADMIN;
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        if (!isAdmin(session)) return "redirect:/login";
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        model.addAttribute("totalSales", saleService.getTotalSales());
        model.addAttribute("totalBills", saleService.getTotalBillCount());
        model.addAttribute("totalStaff", userService.getAllStaff().size());
        model.addAttribute("totalJewellery", jewelleryService.getAll().size());
        model.addAttribute("lowStockItems", jewelleryService.getLowStock());
        model.addAttribute("recentBills", saleService.getAllBills().stream().limit(5).toList());
        model.addAttribute("activeEmis", saleService.getActiveEmis().size());
        return "admin/dashboard";
    }

    @GetMapping("/staff")
    public String staffList(HttpSession session, Model model) {
        if (!isAdmin(session)) return "redirect:/login";
        model.addAttribute("staffList", userService.getAllStaff());
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        return "admin/staff";
    }

    @PostMapping("/staff/add")
    public String addStaff(@RequestParam String username, @RequestParam String password,
                           @RequestParam String fullName, @RequestParam(required=false) String phone,
                           @RequestParam(required=false) String email,
                           HttpSession session, RedirectAttributes ra) {
        if (!isAdmin(session)) return "redirect:/login";
        try {
            userService.addStaff(username, password, fullName, phone, email);
            ra.addFlashAttribute("success", "Staff member added successfully");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/staff";
    }

    @PostMapping("/staff/deactivate/{id}")
    public String deactivateStaff(@PathVariable Long id, HttpSession session, RedirectAttributes ra) {
        if (!isAdmin(session)) return "redirect:/login";
        userService.deactivateStaff(id);
        ra.addFlashAttribute("success", "Staff deactivated");
        return "redirect:/admin/staff";
    }

    @GetMapping("/jewellery")
    public String jewelleryList(HttpSession session, Model model) {
        if (!isAdmin(session)) return "redirect:/login";
        model.addAttribute("jewelleryList", jewelleryService.getAll());
        model.addAttribute("categories", Jewellery.Category.values());
        model.addAttribute("types", Jewellery.JewelleryType.values());
        model.addAttribute("materials", Jewellery.Material.values());
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        return "admin/jewellery";
    }

    @PostMapping("/jewellery/add")
    public String addJewellery(@RequestParam String name, @RequestParam(required=false) String description,
                               @RequestParam String category, @RequestParam String type,
                               @RequestParam String material, @RequestParam(required=false) Double weightGrams,
                               @RequestParam(required=false) Double caratWeight,
                               @RequestParam(defaultValue="1") Integer stockQuantity,
                               @RequestParam(required=false) String imageUrl,
                               @RequestParam(required=false) MultipartFile imageFile,
                               HttpSession session, RedirectAttributes ra) {
        if (!isAdmin(session)) return "redirect:/login";
        try {
            JewelleryRequest req = new JewelleryRequest();
            req.setName(name);
            req.setDescription(description);
            req.setCategory(Jewellery.Category.valueOf(category));
            req.setType(Jewellery.JewelleryType.valueOf(type));
            req.setMaterial(Jewellery.Material.valueOf(material));
            req.setWeightGrams(weightGrams);
            req.setCaratWeight(caratWeight);
            req.setStockQuantity(stockQuantity);
            String storedImage = fileStorageUtil.saveImage(imageFile);
            req.setImageUrl(storedImage != null ? storedImage : imageUrl);
            jewelleryService.addJewellery(req);
            ra.addFlashAttribute("success", "Jewellery added successfully");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/jewellery";
    }

    @PostMapping("/jewellery/delete/{id}")
    public String deleteJewellery(@PathVariable Long id, HttpSession session, RedirectAttributes ra) {
        if (!isAdmin(session)) return "redirect:/login";
        jewelleryService.deleteJewellery(id);
        ra.addFlashAttribute("success", "Jewellery removed");
        return "redirect:/admin/jewellery";
    }

    @PostMapping("/jewellery/stock/{id}")
    public String addStock(@PathVariable Long id, @RequestParam int qty,
                           HttpSession session, RedirectAttributes ra) {
        if (!isAdmin(session)) return "redirect:/login";
        jewelleryService.addStock(id, qty);
        ra.addFlashAttribute("success", "Stock updated");
        return "redirect:/admin/jewellery";
    }

    @GetMapping("/prices")
    public String pricesPage(HttpSession session, Model model) {
        if (!isAdmin(session)) return "redirect:/login";
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        return "admin/prices";
    }

    @PostMapping("/prices/update")
    public String updatePrices(@RequestParam(required=false) Double gold,
                               @RequestParam(required=false) Double silver,
                               @RequestParam(required=false) Double platinum,
                               @RequestParam(required=false) Double diamond,
                               HttpSession session, RedirectAttributes ra) {
        if (!isAdmin(session)) return "redirect:/login";
        shopConfigService.updatePrices(gold, silver, platinum, diamond);
        session.setAttribute("shopConfig", shopConfigService.getConfig());
        ra.addFlashAttribute("success", "Prices updated successfully");
        return "redirect:/admin/prices";
    }

    @GetMapping("/reports")
    public String reportsPage(HttpSession session, Model model) {
        if (!isAdmin(session)) return "redirect:/login";
        model.addAttribute("shopConfig", shopConfigService.getConfig());
        model.addAttribute("allBills", saleService.getAllBills());
        model.addAttribute("totalSales", saleService.getTotalSales());
        model.addAttribute("totalBills", saleService.getTotalBillCount());
        model.addAttribute("allCustomers", customerService.getAll());
        model.addAttribute("activeEmis", saleService.getActiveEmis());
        return "admin/reports";
    }

    @PostMapping("/settings/update")
    public String updateSettings(@RequestParam String shopName,
                                 @RequestParam(required=false) String address,
                                 @RequestParam(required=false) String phone,
                                 @RequestParam(required=false) String email,
                                 @RequestParam(required=false) Double exchangeDeductionPercent,
                                 HttpSession session, RedirectAttributes ra) {
        if (!isAdmin(session)) return "redirect:/login";
        shopConfigService.updateShopDetails(shopName, address, phone, email);
        shopConfigService.updateExchangeDeduction(exchangeDeductionPercent);
        ShopConfig config = shopConfigService.getConfig();
        session.setAttribute("shopConfig", config);
        ra.addFlashAttribute("success", "Settings updated");
        return "redirect:/admin/dashboard";
    }
}
