package com.jewellery.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "shop_config")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ShopConfig {
    @Id
    private Long id;

    @PrePersist
    protected void onCreate() {
        if (this.id == null) {
            this.id = com.jewellery.util.IdGenerator.nextId();
        }
    }

    @Column(nullable = false)
    private String shopName;

    private String shopAddress;
    private String shopPhone;
    private String shopEmail;
    private String logoUrl;

    private Double goldPricePerGram = 6500.0;
    private Double silverPricePerGram = 85.0;
    private Double platinumPricePerGram = 3200.0;
    private Double diamondPricePerCarat = 300000.0;
    private Double exchangeDeductionPercent = 10.0;

    private boolean initialized = false;
}
