package com.jewellery.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "exchanges")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Exchange {
    @Id
    private Long id;

    @PrePersist
    protected void onCreate() {
        if (this.id == null) {
            this.id = com.jewellery.util.IdGenerator.nextId();
        }
    }

    @ManyToOne
    @JoinColumn(name = "bill_id")
    private Bill bill;

    private String oldItemDescription;

    @Enumerated(EnumType.STRING)
    private Jewellery.Material oldMaterial;

    private Double oldWeightGrams;
    private Double metalPriceAtExchange;
    private Double grossValue;
    private Double deductionPercent;
    private Double deductionAmount;
    private Double netExchangeValue;

    private LocalDateTime exchangeDate = LocalDateTime.now();
}
