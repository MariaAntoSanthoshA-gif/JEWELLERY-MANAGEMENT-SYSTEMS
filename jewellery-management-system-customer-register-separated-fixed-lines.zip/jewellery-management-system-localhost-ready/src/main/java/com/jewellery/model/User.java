package com.jewellery.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {
    @Id
    private Long id;

    @PrePersist
    protected void onCreate() {
        if (this.id == null) {
            this.id = com.jewellery.util.IdGenerator.nextId();
        }
    }

    @Column(unique = true, nullable = false)
    private String username;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String fullName;

    private String phone;
    private String email;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role;

    private boolean active = true;

    public enum Role {
        ADMIN, STAFF, CUSTOMER
    }
}
