package com.jewellery.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "customers")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Customer {
    @Id
    private Long id;

    @PrePersist
    protected void onCreate() {
        if (this.id == null) {
            this.id = com.jewellery.util.IdGenerator.nextId();
        }
    }

    private String name;

    @Column(unique = true)
    private String phone;

    private String email;
    private String address;

    @OneToOne
    @JoinColumn(name = "user_id", unique = true)
    private User user;

    private String loginUsername;
    private String loginPassword;

    @Column(updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
}
