package com.jewellery.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "jewellery")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Jewellery {
    @Id
    private Long id;

    @PrePersist
    protected void onCreate() {
        if (this.id == null) {
            this.id = com.jewellery.util.IdGenerator.nextId();
        }
    }

    @Column(nullable = false)
    private String name;

    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Category category;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private JewelleryType type;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Material material;

    private Double weightGrams;
    private Double caratWeight;  // for diamonds

    private Integer stockQuantity = 0;
    private String imageUrl;

    private boolean available = true;

    public enum Category {
        KIDS, BOYS, GIRLS, MEN, WOMEN
    }

    public enum JewelleryType {
        RING, NECKLACE, CHAIN, BRACELET, EARRINGS,
        BANGLES, PENDANT, ANKLET, MANGALSUTRA,
        STUDS, HANGINGS, DROPS, JHUMKAS, HOOPS,
        CHOKER, TOE_RING, WATCH_CHARM
    }

    public enum Material {
        GOLD, SILVER, DIAMOND, PLATINUM
    }
}
