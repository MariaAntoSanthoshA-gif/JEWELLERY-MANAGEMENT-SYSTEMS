package com.jewellery.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "bills")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Bill {
    @Id
    private Long id;

    @PrePersist
    protected void onCreate() {
        if (this.id == null) {
            this.id = com.jewellery.util.IdGenerator.nextId();
        }
    }

    @Column(unique = true, nullable = false)
    private String billNumber;

    @ManyToOne
    @JoinColumn(name = "jewellery_id")
    private Jewellery jewellery;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @ManyToOne
    @JoinColumn(name = "staff_id")
    private User staff;

    private String customerName;
    private String customerPhone;

    private Double jewelleryWeight;
    private Double metalPriceAtSale;
    private Double basePrice;
    private Double makingCharges;
    private Double payableBeforeExchange;
    private Double exchangeDeduction = 0.0;
    private Double returnAmount = 0.0;
    private Double totalAmount;
    private Double amountPaid;

    @Enumerated(EnumType.STRING)
    private PaymentType paymentType;

    @Enumerated(EnumType.STRING)
    private BillStatus status;

    private LocalDateTime billDate = LocalDateTime.now();
    private String notes;

    public enum PaymentType {
        FULL_PAYMENT, EMI, EXCHANGE_PLUS_PAYMENT
    }

    public enum BillStatus {
        COMPLETED, PENDING_EMI, CANCELLED
    }
}
