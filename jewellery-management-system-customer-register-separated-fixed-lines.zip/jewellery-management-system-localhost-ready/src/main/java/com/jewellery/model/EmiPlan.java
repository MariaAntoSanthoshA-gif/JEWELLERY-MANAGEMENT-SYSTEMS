package com.jewellery.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "emi_plans")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmiPlan {
    @Id
    private Long id;

    @PrePersist
    protected void onCreate() {
        if (this.id == null) {
            this.id = com.jewellery.util.IdGenerator.nextId();
        }
    }

    @ManyToOne
    @JoinColumn(name = "bill_id")
    private Bill bill;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    private Double totalAmount;
    private Double downPayment;
    private Double remainingAmount;
    private Integer totalMonths;
    private Double monthlyEmi;
    private Integer paidMonths = 0;
    private Double totalPaid;

    @Enumerated(EnumType.STRING)
    private EmiStatus status;

    private LocalDate nextDueDate;
    private LocalDateTime createdAt = LocalDateTime.now();

    public enum EmiStatus {
        ACTIVE, COMPLETED, DEFAULTED
    }
}
