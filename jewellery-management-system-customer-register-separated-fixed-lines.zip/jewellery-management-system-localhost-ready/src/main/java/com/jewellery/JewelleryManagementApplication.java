package com.jewellery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JewelleryManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(JewelleryManagementApplication.class, args);
    }
}
