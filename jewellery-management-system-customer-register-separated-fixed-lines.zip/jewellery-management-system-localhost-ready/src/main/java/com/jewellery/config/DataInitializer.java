package com.jewellery.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {
    @Override
    public void run(String... args) {
        // Intentionally left blank.
        // The user requested that ornaments must be added only by the admin,
        // not seeded randomly during application startup.
    }
}
