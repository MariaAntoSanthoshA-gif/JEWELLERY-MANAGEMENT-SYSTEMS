# Jewellery Management System

A Spring Boot + Thymeleaf + SQLite localhost project modeled after RaheshEL, customized for a jewellery shop.

## Roles
- **Admin**: first login, sets shop details and daily rates, adds ornaments, manages staff, views reports and recent bills.
- **Staff**: sells items, handles exchange, creates EMI plans, registers customers, gives recommendations.
- **Customer**: logs in using credentials auto-created at registration and can view bills, EMI history, and recommendations.

## Key customizations added
- Admin-first setup page with **shop name + today’s gold/silver/platinum/diamond rates**.
- **No random ornaments are seeded** on startup.
- Admin adds ornaments only through the required flow: **category -> type -> weight -> photo upload**.
- Exchange logic supports both cases:
  - old jewel value is less than new jewel -> customer pays the difference
  - old jewel value is more than new jewel -> system shows amount to return to customer
- Customer credentials are generated when staff registers a customer.

## Default first login
- Username: `admin`
- Password: `admin123`

## Run locally
### Option 1: Maven
```bash
mvn spring-boot:run
```

### Option 2: Build jar
```bash
mvn clean package
java -jar target/jewellery-management-1.0.0.jar
```

Then open:
```text
http://localhost:8080
```

## Tech stack
- Java 17
- Spring Boot 3
- Thymeleaf
- Spring Data JPA
- SQLite

## Notes
- Database file: `jewellery.db`
- Uploaded images are stored under `src/main/resources/static/uploads`
- If you want a fresh start, delete `jewellery.db` before running again.
